import os,re
import time
import requests
import subprocess
import RPi.GPIO as GPIO
import serial,binascii

RES = "640x480"
DIRPATH = "/home/pi/img"
url = "http://192.168.1.108:8002/checkValidity"
filename = time.strftime("%Y%m%d-%H%M%S",time.localtime(time.time()))+ ".jpg"
cmd = "fswebcam -d /dev/video2 --no-banner -r "+ RES +" "+ DIRPATH + "/" + filename
pat = DIRPATH + "/" + "[0-9]{8}-[0-9]{6}.jpg"


def init():
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(11,GPIO.IN)#key
    GPIO.setup(12,GPIO.OUT)#red
    GPIO.setup(13,GPIO.OUT)#green
    GPIO.setup(15,GPIO.OUT)#buzzer
    GPIO.output(15,GPIO.HIGH)
    while True:
        if GPIO.input(11)==GPIO.HIGH:
            GPIO.output(12,GPIO.LOW)
            GPIO.output(13,GPIO.LOW)
            #GPIO.output(15,GPIO.HIGH)
            
            main()


def DataToString(argv,rcv):        
    try:
        result = ''  
        hLen = len(argv)  
        for i in range(hLen):  
         hvol = argv[i]
         hhex = '%02x'%hvol  
         result += hhex+' '  
        print('Recive:',result)
        DataProcess(result,rcv)
    except:
        pass
    
def DataProcess(str,ret):
    str = str.split(' ')
    length = len(str)
    if length < 24:
        ret.append("16")
    else:
        i = int(length / 24)
        div = ''
        while i > 0:
            ret.append(div.join(str[(i-1)*24+6:(i-1)*24+20]))
            i -= 1    
    return ret

def getRFID():
    ser = serial.Serial("/dev/ttyAMA0", 115200)  
    ser.flushInput()  
    id = []
    for i in range(30):
        ser.write(bytes.fromhex("AA 00 22 00 00 22 DD"))  
        time.sleep(0.02)
        #asyncio.sleep(0.1)
        count = ser.inWaiting() 
        if count != 0:
            var = ser.read(count)  
            DataToString(var,id)
            ser.flushInput()
    n = list(set(id))
    if n.count('16')!=0:
        if len(n)==1:
            return("None")
        else:
            n.remove('16')
            return(n)
    else:        
        return(n) 

def main():
    timestart = time.perf_counter()
    Id = getRFID()#uid
    
    if (Id!="None"):
        data = {'deviceIdList':Id}
        print(data)
        result = subprocess.getoutput(cmd)#photo
        #print(result)
        filepath = re.search(pat,result).group()
        #print(filepath)
        files = {'carrierPhoto':(filename,open(filepath,'rb'))}
        print(files)
    
        
        try:
            r = requests.post(url=url,files=files,data=data,timeout=5)
        except Exception as e:
            print(e)
        else:
            timeend = time.perf_counter()
            print(r.text)
            print("time spend:" + str(timeend - timestart) + "s")
            if(r.text == "false"):
                GPIO.output(12,GPIO.HIGH)
                GPIO.output(15,GPIO.LOW)
                time.sleep(5)
                GPIO.output(15,GPIO.HIGH)
            if(r.text == "true"):
                GPIO.output(13,GPIO.HIGH)
                time.sleep(5)
                
    else:
        print("No Device")
        timeend = time.perf_counter()
        print("time spend:" + str(timeend - timestart) + "s")
        GPIO.output(13,GPIO.HIGH)
        time.sleep(3)
        GPIO.output(13,GPIO.LOW)
        
if __name__=="__main__":
    init()
        
