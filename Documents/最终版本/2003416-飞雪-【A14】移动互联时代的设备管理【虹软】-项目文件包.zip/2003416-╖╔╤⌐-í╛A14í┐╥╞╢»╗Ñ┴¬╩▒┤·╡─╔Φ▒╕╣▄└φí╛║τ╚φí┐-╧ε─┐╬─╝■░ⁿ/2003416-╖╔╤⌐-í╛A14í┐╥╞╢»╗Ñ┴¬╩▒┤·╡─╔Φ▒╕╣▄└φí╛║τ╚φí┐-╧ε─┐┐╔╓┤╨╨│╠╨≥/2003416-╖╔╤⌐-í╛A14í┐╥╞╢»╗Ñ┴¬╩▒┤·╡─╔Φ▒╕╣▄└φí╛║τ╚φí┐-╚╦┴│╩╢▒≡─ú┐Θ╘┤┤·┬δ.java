package team.feixue.device_manager.util;

import com.arcsoft.face.*;
import com.arcsoft.face.enums.*;
import com.arcsoft.face.toolkit.ImageInfo;
import team.feixue.device_manager.exception.MyException;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static com.arcsoft.face.toolkit.ImageFactory.getRGBData;

//出于项目需要，这里在虹软定义的错误代码基础上再定义三种错误：未检测到人脸错误、非同一人脸错误和非活体错误。
enum MyErrorInfo {
    NO_FACE(103),
    NOT_SAME_FACE(104),
    NOT_ALIVE_PERSON(105);

    private final int value;

    MyErrorInfo(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }
}

/**
 * 人脸识别工具类
 *
 * @author lyh
 * @since 2021-03-25
 */
public class PhotoCheckUtils {
    private static FaceEngine faceEngine;

    public static boolean checkDeviceValidity(byte[] holderImage, File carrierImage) {
        int statusCode = PhotoCheckUtils.facesCompare(holderImage, carrierImage);

        return statusCode == 0;
    }

    // 激活引擎
    public static void activeMyFaceEngine() {
        // 激活Id、Key
        String appId = "3VAdEQAWiD57pQ3zJffWpLe46UsrJKejFzqZ9LV2XatE";
        String sdkKey = "7JqH12TFziLkbsuAzmgfdhx1PsCtmZPgrQbPMkcCumBn";

        faceEngine = new FaceEngine(PhotoCheckUtils.class.getClassLoader().getResource("lib").getPath());

        //激活引擎
        int statusCode = faceEngine.activeOnline(appId, sdkKey);
        if (statusCode != ErrorInfo.MOK.getValue() && statusCode != ErrorInfo.MERR_ASF_ALREADY_ACTIVATED.getValue()) {
            //如果人脸识别引擎激活失败，则抛出异常和提示信息
            throw new MyException(statusCode, "人脸识别引擎激活失败！");
        }

        ActiveFileInfo activeFileInfo = new ActiveFileInfo();
        statusCode = faceEngine.getActiveFileInfo(activeFileInfo);
        if (statusCode != ErrorInfo.MOK.getValue() && statusCode != ErrorInfo.MERR_ASF_ALREADY_ACTIVATED.getValue()) {
            //如果获取激活文件信息失败，则抛出异常和提示信息
            throw new MyException(statusCode, "获取激活文件信息失败！");
        }

        //引擎配置
        EngineConfiguration engineConfiguration = new EngineConfiguration();
        engineConfiguration.setDetectMode(DetectMode.ASF_DETECT_MODE_IMAGE);
        engineConfiguration.setDetectFaceOrientPriority(DetectOrient.ASF_OP_ALL_OUT);
        engineConfiguration.setDetectFaceMaxNum(10);
        engineConfiguration.setDetectFaceScaleVal(16);

        //功能配置
        FunctionConfiguration functionConfiguration = new FunctionConfiguration();
        functionConfiguration.setSupportFaceDetect(true);
        functionConfiguration.setSupportFaceRecognition(true);
        functionConfiguration.setSupportLiveness(true);
        engineConfiguration.setFunctionConfiguration(functionConfiguration);

        //初始化引擎
        statusCode = faceEngine.init(engineConfiguration);
        if (statusCode != ErrorInfo.MOK.getValue()) {
            //如果初始化引擎失败，则抛出异常和提示信息
            throw new MyException(statusCode, "初始化引擎失败！");
        }
    }

    // 提取人像特征值
    public static byte[] getImageInfo(File picture) {
        FaceFeature faceFeature = new FaceFeature();
        //人脸检测
        ImageInfo imageInfo = getRGBData(picture);
        List<FaceInfo> faceInfoList = new ArrayList<>();

        int statusCode = faceEngine.detectFaces(imageInfo.getImageData(), imageInfo.getWidth(), imageInfo.getHeight(), imageInfo.getImageFormat(), faceInfoList);
        if (statusCode == 0 && faceInfoList.size() > 0) {
            //人脸检测成功并且检测到了人脸，进行特征提取
            faceEngine.extractFaceFeature(imageInfo.getImageData(), imageInfo.getWidth(), imageInfo.getHeight(), imageInfo.getImageFormat(), faceInfoList.get(0), faceFeature);
        } else {
            //人脸检测失败或未检测到人脸，返回未检测到人脸错误，并抛出异常和提示信息
            int value = MyErrorInfo.NO_FACE.getValue();
            throw new MyException(value, "cant detect faceInfo, please try again!");
        }

        return faceFeature.getFeatureData();
    }

    // 比对人脸是否匹配
    public static int facesCompare(byte[] sourceFaceFeatureData, File targetFaceFile) {
        FaceSimilar faceSimilar = new FaceSimilar();
        //提取拍到照片的人脸特征
        FaceFeature sourceFaceFeature = new FaceFeature();
        sourceFaceFeature.setFeatureData(sourceFaceFeatureData);

        //人脸检测
        ImageInfo targetImageInfo = getRGBData(targetFaceFile);
        List<FaceInfo> targetFaceInfoList = new ArrayList<>();
        int statusCode = faceEngine.detectFaces(targetImageInfo.getImageData(), targetImageInfo.getWidth(), targetImageInfo.getHeight(), targetImageInfo.getImageFormat(), targetFaceInfoList);
        if (!(statusCode == 0 && targetFaceInfoList.size() > 0)) {
            //人脸检测失败或未检测到人脸，返回未检测到人脸错误
            return MyErrorInfo.NO_FACE.getValue();
        }

        //人脸检测成功并且检测到了人脸，进行特征提取
        FaceFeature targetFaceFeature = new FaceFeature();
        statusCode = faceEngine.extractFaceFeature(targetImageInfo.getImageData(), targetImageInfo.getWidth(), targetImageInfo.getHeight(), targetImageInfo.getImageFormat(), targetFaceInfoList.get(0), targetFaceFeature);
        if (statusCode != ErrorInfo.MOK.getValue()) {
            return statusCode;
        }

        //特征比对
        statusCode = faceEngine.compareFaceFeature(targetFaceFeature, sourceFaceFeature, faceSimilar);
        if (statusCode != ErrorInfo.MOK.getValue()) {
            return statusCode;
        }

        if (faceSimilar.getScore() < 0.80) {
            //不是同一个人，返回非同一人脸错误
            return MyErrorInfo.NOT_SAME_FACE.getValue();
        }

        //是同一个人，进行活体检测
        statusCode = faceEngine.setLivenessParam(0.5f, 0.7f);
        if (statusCode != ErrorInfo.MOK.getValue()) {
            return statusCode;
        }
        FunctionConfiguration configuration = new FunctionConfiguration();
        configuration.setSupportLiveness(true);
        statusCode = faceEngine.process(targetImageInfo.getImageData(), targetImageInfo.getWidth(), targetImageInfo.getHeight(), targetImageInfo.getImageFormat(), targetFaceInfoList, configuration);
        if (statusCode != ErrorInfo.MOK.getValue()) {
            return statusCode;
        }

        //活体检测
        List<LivenessInfo> livenessInfoList = new ArrayList<>();
        statusCode = faceEngine.getLiveness(livenessInfoList);
        if (statusCode != ErrorInfo.MOK.getValue()) {
            return statusCode;
        }

        if (livenessInfoList.size() > 0 && livenessInfoList.get(0).getLiveness() < 0.5) {
            //识别到的人脸非活体，返回非活体错误
            return MyErrorInfo.NOT_ALIVE_PERSON.getValue();
        }

        return statusCode;
    }
}